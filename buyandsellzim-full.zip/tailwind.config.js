module.exports = {
  content: ['./src/**/*.{js,jsx,ts,tsx}', './src/pages/**/*.{js,jsx,ts,tsx}'],
  theme: {
    extend: {
      colors: {
        brandBlue: '#0b69ff',
        brandRed: '#ff2d55',
        brandGray: '#374151'
      }
    }
  },
  plugins: []
}
