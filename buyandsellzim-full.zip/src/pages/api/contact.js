export default async function handler(req, res){
  if(req.method !== 'POST') return res.status(405).end()
  const endpoint = process.env.FORMSPREE_ENDPOINT || 'https://formspree.io/f/mandvjgz'
  const r = await fetch(endpoint, {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(req.body)})
  const data = await r.text()
  res.status(r.status).send(data)
}
