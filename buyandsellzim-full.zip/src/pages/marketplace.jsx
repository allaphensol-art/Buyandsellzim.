export default function Marketplace(){
  const products = [
    {name:'Smartphone',price:'$120',seller:'Harare'},
    {name:'Designer Jacket',price:'$60',seller:'Bulawayo'},
    {name:'Fresh Groceries',price:'$25',seller:'Harare'},
    {name:'Laptop',price:'$450',seller:'Harare'},
  ]
  return (
    <main className="max-w-7xl mx-auto px-6 py-10">
      <h1 className="text-3xl font-bold mb-6">Marketplace</h1>
      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-4 gap-6">
        {products.map((p,i)=>(
          <div key={i} className="bg-white p-4 rounded shadow">
            <div className="h-36 bg-gray-200 mb-3"></div>
            <div className="font-semibold">{p.name}</div>
            <div className="text-sm text-gray-500">Seller • {p.seller}</div>
            <div className="mt-3 font-bold text-brandBlue">{p.price}</div>
          </div>
        ))}
      </div>
    </main>
  )
}
