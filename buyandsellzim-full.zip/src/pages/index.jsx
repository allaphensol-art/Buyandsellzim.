import Link from 'next/link'
export default function Home(){
  return (
    <main className="max-w-7xl mx-auto px-6 py-12">
      <section className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
        <div>
          <h1 className="text-4xl md:text-5xl font-extrabold text-brandBlue">Buy & Sell, <span className="text-brandRed">locally</span> in Zimbabwe</h1>
          <p className="mt-4 text-gray-700 max-w-xl">A professional marketplace built for Zimbabwe — trusted sellers, secure payments, and fast local delivery.</p>
          <div className="mt-6 flex gap-4">
            <Link href="/marketplace" className="px-6 py-3 rounded-full bg-brandBlue text-white">Start Shopping</Link>
            <Link href="/services" className="px-6 py-3 rounded-full border border-brandRed text-brandRed">Browse Services</Link>
          </div>
        </div>
        <div>
          <div className="rounded-2xl overflow-hidden shadow-xl bg-gray-50 p-6">
            <div className="grid grid-cols-2 gap-4">
              {['Electronics','Fashion','Groceries','Services'].map(c=> (
                <div key={c} className="bg-white rounded-lg p-4">
                  <div className="w-full h-28 bg-gray-200 rounded mb-2"></div>
                  <div className="font-medium">{c}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>
    </main>
  )
}
