export default function Services(){
  const services = [
    {title:'Plumbing',price:'From $20'},
    {title:'Transport (Taxi)',price:'From $5'},
    {title:'House Cleaning',price:'From $15'},
    {title:'Freelance IT',price:'From $30'},
  ]
  return (
    <main className="max-w-7xl mx-auto px-6 py-10">
      <h1 className="text-3xl font-bold mb-6">Services Marketplace</h1>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {services.map((s,i)=>(
          <div key={i} className="bg-white p-4 rounded shadow">
            <div className="font-semibold">{s.title}</div>
            <div className="text-sm text-gray-500">Top providers • Local</div>
            <div className="font-bold mt-3">{s.price}</div>
            <button className="mt-4 bg-indigo-600 text-white px-3 py-2 rounded">Book</button>
          </div>
        ))}
      </div>
    </main>
  )
}
