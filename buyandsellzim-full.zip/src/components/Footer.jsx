export default function Footer(){
  return (
    <footer className="bg-gray-900 text-white mt-12">
      <div className="max-w-7xl mx-auto px-6 py-10 grid grid-cols-1 md:grid-cols-3 gap-8">
        <div>
          <h4 className="font-bold text-lg">BuyAndSellZim</h4>
          <p className="text-sm text-gray-300 mt-2">Trusted marketplace & services — connecting Zimbabwe.</p>
          <p className="text-xs text-gray-400 mt-4">Contact: info@buyandsellzim.co.zw</p>
        </div>
        <div>
          <h4 className="font-semibold">Explore</h4>
          <ul className="mt-3 space-y-2 text-sm text-gray-300">
            <li><a href="/marketplace">Marketplace</a></li>
            <li><a href="/services">Services</a></li>
            <li><a href="/contact">Contact</a></li>
          </ul>
        </div>
        <div>
          <h4 className="font-semibold">Follow</h4>
          <div className="flex gap-3 mt-3 text-sm">
            <a href="https://wa.me/263773151367" className="text-green-400">WhatsApp</a>
            <a href="https://facebook.com/BuyAndSellZim" className="text-blue-400">Facebook</a>
          </div>
        </div>
      </div>
      <div className="border-t border-gray-800 text-center py-4 text-xs text-gray-500">© {new Date().getFullYear()} BuyAndSellZim</div>
    </footer>
  )
}
