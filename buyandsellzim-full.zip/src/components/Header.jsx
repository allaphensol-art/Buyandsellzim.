import Link from 'next/link'
export default function Header(){
  return (
    <header className="bg-gray-200 border-b">
      <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-3">
          <img src="/logo-icon.svg" alt="logo" className="w-11 h-11" />
          <div className="text-xl font-bold text-brandBlue">Buy<span className="text-brandRed">AndSell</span>Zim</div>
        </Link>
        <nav className="flex items-center gap-4">
          <Link href="/marketplace" className="text-sm">Marketplace</Link>
          <Link href="/services" className="text-sm">Services</Link>
          <Link href="/contact" className="text-sm">Contact</Link>
          <a href="https://wa.me/263773151367" className="px-3 py-2 bg-green-600 text-white rounded">WhatsApp</a>
        </nav>
      </div>
    </header>
  )
}
