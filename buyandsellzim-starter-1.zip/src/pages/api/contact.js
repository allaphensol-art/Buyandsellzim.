export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end();
  const endpoint = process.env.FORMSPREE_ENDPOINT;
  const response = await fetch(endpoint, {
    method: 'POST',
    body: JSON.stringify(req.body),
    headers: { 'Content-Type': 'application/json' }
  });
  const data = await response.json();
  res.status(response.status).json(data);
}