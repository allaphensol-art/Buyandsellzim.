export default function Home() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center text-center p-6">
      <h1 className="text-4xl font-bold text-brandBlue">Welcome to BuyAndSellZim</h1>
      <p className="mt-4 text-lg text-gray-700">Your Zimbabwean Marketplace & Services Hub</p>
      <a href="/marketplace" className="mt-6 px-6 py-3 bg-brandRed text-white rounded-lg">Start Shopping</a>
    </div>
  )
}