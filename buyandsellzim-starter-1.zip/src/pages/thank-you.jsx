export default function ThankYou() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100 p-6">
      <div className="bg-white p-10 rounded-2xl shadow text-center max-w-md">
        <h1 className="text-3xl font-bold text-green-600 mb-4">🎉 Thank you!</h1>
        <p className="text-gray-700 mb-6">You’re on the list — we’ll notify you at launch.</p>
        <a href="/" className="inline-block px-6 py-3 bg-brandBlue text-white rounded">Back to Home</a>
      </div>
    </div>
  )
}